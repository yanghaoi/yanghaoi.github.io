# AndroidManifest.xml（二进制 AXML）修复文档

> 适用场景：用 `AXMLPrinter2.jar` 解码 APK 中的 `AndroidManifest.xml` 失败，
> 报 `Expected chunk of type 0x80003...`、`Invalid chunk type...` 等错误，
> 或提取出来的 manifest 打不开 / 乱码。
>
> 配套工具：`fix_axml.py`（与本文件同目录，一键修复脚本）。

---

## 一、快速诊断（先看这里）

### 1.1 判断文件当前状态

```bash
xxd AndroidManifest.xml | head -3
file AndroidManifest.xml
```

| 文件头特征 | 状态 | 处理 |
|---|---|---|
| `03 00 08 00` | 标准老格式 AXML | 直接 `java -jar AXMLPrinter2.jar` 解码 |
| `03 00 0c 00` | 新 aapt2 格式（根块头 12 字节） | 需修补，见坑①（第 10 字节起常为 `00 00 00 00`） |
| 开头正常但正文有大量 `ef bf bd` | 被文本编码转换**损坏** | 不可逆，必须回 APK 重新提取，见坑③ |
| `50 4b 03 04` (`PK..`) | 这其实是个 APK/ZIP 包 | 用二进制方式提取其中的 manifest |
| `3c 3f 78 6d` (`<?xm`) | 已经是可读文本 XML | 无需处理 |

### 1.2 检测是否被编码损坏

```bash
python -c "d=open('AndroidManifest.xml','rb').read();print('EFBFBD 数量:',d.count(b'\xef\xbf\xbd'))"
```

正常二进制 manifest 中 `EF BF BD`（U+FFFD 替换字符）应为 0 或极个别；
出现成百上千个 = 文件曾被"按文本复制/传输"，**原始字节已永久丢失，无法就地修复**。

### 1.3 AXMLPrinter2 报错对照表

| 报错信息 | 原因 | 解决 |
|---|---|---|
| `Expected chunk of type 0x80003, read 0xc0003` | 根块 headerSize=0x0C（新格式），老工具只认 0x08 | 坑①修补 |
| `Invalid chunk type (7077934)` 之类的奇怪数值 | 字符串池对齐填充导致解析错位 | 坑②修补 |
| `Expected chunk of type 0x1c0001, read 0x...` | 文件损坏 / 提取错误 | 坑③，回 APK 重新提取 |
| `String data size is not multiple of 4` | 文件损坏或结构被截断 | 坑③ |
| 输出中文乱码但结构正常 | Windows 控制台 GBK 编码 | 坑④，加 `-Dfile.encoding=UTF-8` |

---

## 二、原理速览

### 2.1 AXML 文件结构

```
偏移   结构
0x00   根块 RES_XML_TYPE (type=0x0003)
       ├─ 老格式: headerSize=0x08  [type:2][hs:2][size:4]
       └─ 新格式: headerSize=0x0C  [type:2][hs:2][size:4][保留:4]   ← 坑①
0x08   字符串池 RES_STRING_POOL_TYPE (type=0x0001, headerSize=0x1C)
       [块头 28B][偏移表 4*N 字节][可能的对齐填充][字符串数据][样式数据]
                                   ↑ 坑②：新 aapt2 会插入填充
随后   资源映射块(0x0180) → 命名空间(0x100/0x101) → 元素(0x102/0x103) ...
```

AXMLPrinter2（2010 年前后的工具）按**顺序流式**读取：读完块头和偏移表后
紧接着读"字符串数据"。它不知道偏移表和数据之间可能有填充，也不知道根块
头可能是 12 字节——于是整体错位，报出莫名其妙的错误。

### 2.2 四个坑

**坑① 根块新头（headerSize=0x0C）**
新版 Android 构建链（AGP 7+ / Android 12+ 的 aapt2）会把根块头写成 12 字节，
多出的 4 字节为保留字段（通常是 `00 00 00 00`）。
修法：`0C` 改 `08`，删掉那 4 字节，根块 size 减 4。

**坑② 字符串池对齐填充**
新 aapt2 会在偏移表之后、字符串数据之前插入若干字节的 0 填充做对齐
（`stringsStart > 28 + 4*字符串数`）。老工具不跳过这段填充，后续全部错位。
修法：算出 `gap = stringsStart - (28 + 4*(stringCount+styleCount))`，
删掉这 gap 个字节，并同步修正：字符串池 size、stringsStart、stylesStart（若非 0）、根块 size。
字符串偏移都是相对 stringsStart 的，删填充不影响任何引用。

**坑③ 文本模式提取损坏（不可逆）**
用文本方式（记事本复制、FTP 文本模式、某些解压前端、聊天工具传文件）
处理二进制 manifest 时，>0x7F 的字节按 UTF-8 解码失败，被替换成
U+FFFD（写回即 `EF BF BD`），原始数据永久丢失。
修法：回到 APK，用二进制方式重新提取：

```bash
unzip -p xxx.apk AndroidManifest.xml > AndroidManifest.xml     # 二进制，安全
# 或 Python:
python -c "import zipfile;open('m.xml','wb').write(zipfile.ZipFile('xxx.apk').read('AndroidManifest.xml'))"
```

**如何确认损坏文件来自哪个 APK**（多个 APK 候选时）：
对每个候选 APK 提取 manifest，模拟同样的损坏，能逐字节复现即为来源：

```python
orig.decode('utf-8', errors='replace').encode('utf-8') == 损坏文件字节
```

**坑④ Windows 输出乱码**
Java 的 System.out 在中文 Windows 上默认 GBK，重定向出的 XML 中文会乱码。
运行时加 `-Dfile.encoding=UTF-8`（脚本已内置）。

---

## 三、一键修复（推荐）

```bash
# 情况 A：手头是被损坏/新格式的 AndroidManifest.xml（自动在同目录找候选 APK）
python fix_axml.py AndroidManifest.xml

# 情况 B：指定候选 APK（可多个）
python fix_axml.py AndroidManifest.xml app1.apk app2.apk

# 情况 C：直接从 APK 提取并解码
python fix_axml.py xxx.apk
```

脚本流程：
1. 识别输入（APK / 二进制 AXML / 已损坏 / 已是文本）
2. 若检测到 `EF BF BD` 损坏 → 用"模拟损坏比对"自动定位来源 APK 并重新提取
3. 应用坑①②补丁，生成兼容旧工具的副本
4. 用解析器模拟走查整个文件，确认修补正确后才调用 Java
5. `java -Dfile.encoding=UTF-8 -jar AXMLPrinter2.jar` 解码
6. 校验输出并打印统计（包名、四大组件数量）

输出文件（以输入名 `X` 为前缀）：

| 文件 | 说明 |
|---|---|
| `X_recovered.xml` | ✅ 最终可读 XML |
| `X_clean.xml` | 从 APK 重新提取的干净二进制（仅当发生了重提取） |
| `X_patched.xml` | 兼容旧工具的修补副本（仅当需要补丁） |

---

## 四、手工修复步骤（脚本不可用时）

```bash
# 1. 从 APK 二进制提取（若原文件已损坏）
python -c "import zipfile;open('clean.xml','wb').write(zipfile.ZipFile('app.apk').read('AndroidManifest.xml'))"

# 2. 打补丁（坑①+坑②一次完成）
python << 'EOF'
import struct
d = bytearray(open('clean.xml','rb').read())
t, hs, size = struct.unpack_from('<HHI', d, 0)
if hs == 0x0C:                                   # 坑①
    d = d[:2] + struct.pack('<HI', 8, size-4) + d[12:]
pt, phs, psize = struct.unpack_from('<HHI', d, 8)
cnt, sty, flags, sstart, styoff = struct.unpack_from('<IIIII', d, 16)
gap = sstart - (28 + 4*(cnt+sty))                # 坑②
if gap > 0:
    cut = 8 + 28 + 4*(cnt+sty)
    d = d[:cut] + d[cut+gap:]
    struct.pack_into('<I', d, 12,  psize-gap)
    struct.pack_into('<I', d, 28,  sstart-gap)
    if styoff: struct.pack_into('<I', d, 32, styoff-gap)
    struct.pack_into('<I', d, 4, struct.unpack_from('<I', d, 4)[0]-gap)
open('patched.xml','wb').write(d)
print('patched ok')
EOF

# 3. 解码
java -Dfile.encoding=UTF-8 -jar AXMLPrinter2.jar patched.xml > AndroidManifest_recovered.xml

# 4. 验证：应看到 <manifest ...> 开头、</manifest> 结尾，无 Java 异常
head -15 AndroidManifest_recovered.xml; tail -3 AndroidManifest_recovered.xml
```

---

## 五、预防措施

1. 从 APK 提取任何文件一律用**二进制方式**：`unzip -p`、Python `zipfile`、
   `7z x`；不要用记事本打开后另存，不要走"文本模式"传输。
2. 需要长期保存可读版本时，解码后保存 **文本 XML**，不要保存二进制再指望以后解码。
3. 新构建的 APK（AGP 7+）manifest 用老工具前，先 `xxd | head -1` 看一眼文件头。

---

## 六、局限与替代方案

- 若字符串池 `flags & 0x100`（UTF-8 池），AXMLPrinter2 老版本会解码出乱码
  （它只实现了 UTF-16 读取），此时改用：
  - `apktool d xxx.apk`
  - `androguard`（Python：`from androguard.core.apk import APK; APK('x.apk').get_android_manifest_xml().toprettyxml()`）
  - `jadx`（GUI 直接打开 APK 即可查看 manifest）
- AXMLPrinter2 不解析资源引用，`@7F110215` 之类的值只显示原始 ID，属正常现象；
  需要解析资源值时用 apktool / jadx。
- 加壳样本（如 `cn.com.x.bank`，Application 为 `s.h.e.l.l.S`，
  X加固特征）的 manifest 仍是壳外真实清单，可正常用于组件面分析。
