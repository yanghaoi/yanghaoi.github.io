# AXML 修复工具包

一键修复 `AXMLPrinter2.jar` 无法解码的 `AndroidManifest.xml`。

APK 中的 `AndroidManifest.xml` 是二进制 AXML 格式。用老工具 `AXMLPrinter2.jar`
解码新版构建（AGP 7+ / Android 12+ 的 aapt2）产出的 manifest 时会报错；
提取方式不当还会造成不可逆的编码损坏。本工具包自动识别并修复这些问题。

已实测修复多个银行类加固样本（如 `cn.com.x.bank`）的 manifest。

---

## 目录结构

```
FIX_AXML/
├── README.md                  ← 本文件（原理与用法概览）
├── AndroidManifest修复文档.md ← 详细文档（诊断表、手工步骤、预防措施）
├── fix_axml.py                ← 一键修复脚本（Python3 标准库，无第三方依赖）
└── AXMLPrinter2.jar           ← 二进制 AXML 解码器（脚本自动调用）
```

## 环境要求

- **Python 3.6+**（仅标准库）
- **Java**（任意版本，`java` 在 PATH 中即可；实测 JDK 17 可用）

## 快速上手

```bash
# ① 输入是 APK：自动二进制提取 → 修补 → 解码（最常用）
python fix_axml.py 某某应用.apk

# ② 输入是提取好的 AndroidManifest.xml（新格式或疑似损坏）
python fix_axml.py AndroidManifest.xml
#   若检测到编码损坏，脚本自动在同目录的 *.apk 中比对定位来源并重新提取；
#   也可手动指定候选 APK：
python fix_axml.py AndroidManifest.xml 候选1.apk 候选2.apk

# ③ 输入已经是可读文本 XML：脚本识别后直接跳过
```

脚本可放在任意位置运行，会自动在**脚本所在目录**查找 `AXMLPrinter2.jar`。

## 输出说明

以输入名 `X` 为前缀，生成在**当前工作目录**：

| 文件 | 说明 |
|---|---|
| `X_recovered.xml` | ✅ 最终可读 XML |
| `X_clean.xml` | 从 APK 重新提取的干净二进制（仅发生重提取时） |
| `X_patched.xml` | 兼容旧工具的修补副本（仅需要补丁时） |

结束时打印统计摘要：包名、四大组件数量、Application 类
（如 `s.h.e.l.l.S` 为 X加固壳特征）。

## 原理概览

AXML 文件结构：`根块 → 字符串池 → 资源映射 → 命名空间/元素块`。
AXMLPrinter2 是 2010 年前后的工具，按顺序流式读取，遇到三处"新情况"就失效：

| 坑 | 现象 | 原因 | 脚本的处理 |
|---|---|---|---|
| ① 根块新头 | `Expected chunk of type 0x80003, read 0xc0003` | 新 aapt2 把根块头写成 12 字节（多出 4 字节保留字段），老工具只认 8 字节 | 头改回 0x08，删 4 字节，修正块尺寸 |
| ② 字符串池填充 | `Invalid chunk type (...)` 奇怪数值 | 偏移表与字符串数据之间新增了对齐填充，老工具不跳过，整体错位 | 计算并删除填充，同步修正 4 处尺寸字段 |
| ③ 文本模式损坏 | 文件含大量 `EF BF BD` | 二进制被按 UTF-8 文本读取，非法字节被替换成 U+FFFD，**不可逆** | 模拟损坏比对定位来源 APK，二进制重新提取 |

安全机制：补丁完成后，脚本先**按 AXMLPrinter2 的解析逻辑完整模拟走查**
整个文件，确认所有字节对齐后才真正调用 Java 解码，避免产出半成品。

完整细节（文件头诊断表、报错对照表、手工修复命令、预防措施）见
[AndroidManifest修复文档.md](./AndroidManifest修复文档.md)。

## 常见问题

**Q: 解码结果里 `@7F110215` 这类值是什么？**
A: 资源引用 ID。AXMLPrinter2 不解析资源表，只显示原始值；需要还原成
具体文本/图标时用 `apktool d` 或 `jadx`。

**Q: 输出中文乱码？**
A: 脚本已强制 `-Dfile.encoding=UTF-8`。如果自行手工运行，记得加此参数，
否则中文 Windows 上会输出 GBK 乱码（详见修复文档"坑④"）。

**Q: 提示"字符串池为 UTF-8 编码"警告？**
A: 个别构建使用 UTF-8 字符串池，AXMLPrinter2 老版本不支持，
请改用 `apktool` / `androguard` / `jadx`。

**Q: manifest 解出来了，但代码看不到？**
A: manifest 是壳外真实配置，但应用可能已加壳（Application 为
`s.h.e.l.l.S` 等）。组件面分析可直接基于本清单；运行时逻辑需先脱壳。
