#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_axml.py — 一键修复 AXMLPrinter2 无法解码的 AndroidManifest.xml

支持三种输入：
  A. 被文本编码损坏的 manifest（含大量 EF BF BD）→ 自动定位来源 APK 重新提取
  B. 新 aapt2 格式（根块 headerSize=0x0C / 字符串池带对齐填充）→ 自动打补丁
  C. 直接传入 APK → 二进制提取后解码

用法：
  python fix_axml.py AndroidManifest.xml [候选1.apk 候选2.apk ...]
  python fix_axml.py xxx.apk

依赖：Python3（标准库）+ java + 同目录或当前目录下的 AXMLPrinter2.jar
详见《AndroidManifest修复文档.md》
"""
import glob
import os
import re
import shutil
import struct
import subprocess
import sys
import zipfile

# AXML 块类型（type | headerSize<<16，与 AXMLPrinter2 读取方式一致）
ROOT_08 = 0x00080003          # 根块（老格式，头 8 字节）
ROOT_0C = 0x000C0003          # 根块（新格式，头 12 字节）← 坑①
POOL = 0x001C0001             # 字符串池
RES_MAP = 0x00080180          # 资源映射块
CHUNK_LO, CHUNK_HI = 0x00100100, 0x00100104   # 命名空间/元素/CDATA 块


def read_file(path):
    with open(path, 'rb') as f:
        return f.read()


def write_file(path, data):
    with open(path, 'wb') as f:
        f.write(data)
    print(f"[+] 已写出 {path} ({len(data)} 字节)")


def simulate_corruption(data):
    """复现'按 UTF-8 文本读取再写回'造成的损坏"""
    return data.decode('utf-8', errors='replace').encode('utf-8')


def extract_manifest(apk_path):
    return zipfile.ZipFile(apk_path).read('AndroidManifest.xml')


def find_source_apk(corrupted, apk_list):
    """通过模拟损坏逐字节比对，定位损坏文件的来源 APK"""
    seen = set()
    for apk in apk_list:
        apk = os.path.abspath(apk)
        if apk in seen or not os.path.isfile(apk):
            continue
        seen.add(apk)
        try:
            orig = extract_manifest(apk)
        except Exception:
            continue
        if simulate_corruption(orig) == corrupted:
            return apk, orig
    return None, None


def patch_axml(data):
    """
    把新版 AXML 修补成 AXMLPrinter2 可解析的格式。
    返回 (修补后字节, 是否打过补丁, 说明列表)
    """
    notes = []
    if data[:2] != b'\x03\x00':
        raise ValueError("不是 AXML 文件（缺少 03 00 魔数）")
    d = bytearray(data)
    rt, rhs, rsize = struct.unpack_from('<HHI', d, 0)
    if rt != 0x0003:
        raise ValueError(f"根块类型异常: 0x{rt:04x}")
    patched = False

    # 坑①：根块 headerSize=0x0C → 0x08，删掉 4 字节保留字段
    if rhs == 0x0C:
        extra = bytes(d[8:12])
        if extra != b'\x00' * 4:
            notes.append(f"注意: 根块扩展头部非全零 {extra.hex()}，已强制移除")
        d = d[:2] + struct.pack('<HI', 0x08, rsize - 4) + d[12:]
        patched = True
        notes.append("坑①已修补: 根块头 0x0C→0x08（移除 4 字节保留字段）")
    elif rhs != 0x08:
        raise ValueError(f"根块 headerSize 无法识别: 0x{rhs:04x}")

    # 坑②：字符串池偏移表与数据之间的对齐填充
    pt, phs, psize = struct.unpack_from('<HHI', d, 8)
    if (pt, phs) != (0x0001, 0x1C):
        raise ValueError(f"字符串池头部异常: type=0x{pt:04x} hs=0x{phs:04x}")
    cnt, sty, flags, sstart, styoff = struct.unpack_from('<IIIII', d, 16)
    if flags & 0x100:
        notes.append("警告: 字符串池为 UTF-8 编码，AXMLPrinter2 老版本会乱码，"
                     "建议改用 apktool/androguard/jadx")
    hdr = 28 + 4 * (cnt + sty)
    gap = sstart - hdr
    if gap < 0:
        raise ValueError(f"字符串池 stringsStart 异常 (gap={gap})，文件可能已损坏")
    if gap > 0:
        cut = 8 + hdr
        pad = bytes(d[cut:cut + gap])
        if pad != b'\x00' * gap:
            notes.append(f"注意: 字符串池填充非全零 {pad.hex()}，已强制移除")
        d = d[:cut] + d[cut + gap:]
        struct.pack_into('<I', d, 8 + 4, psize - gap)      # 池 size
        struct.pack_into('<I', d, 8 + 20, sstart - gap)    # stringsStart
        if styoff:
            struct.pack_into('<I', d, 8 + 24, styoff - gap)  # stylesStart
        struct.pack_into('<I', d, 4, struct.unpack_from('<I', d, 4)[0] - gap)  # 根 size
        patched = True
        notes.append(f"坑②已修补: 移除偏移表后 {gap} 字节对齐填充")

    return bytes(d), patched, notes


def verify_walk(d):
    """按 AXMLPrinter2 的解析逻辑完整走查一遍，修补正确则恰好消费到文件尾"""
    pos = 0

    def ri():
        nonlocal pos
        v = struct.unpack_from('<i', d, pos)[0]
        pos += 4
        return v

    if ri() != ROOT_08:
        raise ValueError("根块校验失败")
    ri()  # size
    if ri() != POOL:
        raise ValueError("字符串池校验失败")
    cs, c, s = ri(), ri(), ri()
    ri()  # flags
    ss, so = ri(), ri()
    pos += 4 * (c + s)          # 偏移表
    pos += (so or cs) - ss      # 字符串数据

    prev, events = -1, 0
    while pos < len(d):
        t = 0x00100102 if prev == 0 else ri()
        if t == RES_MAP:
            sz = ri()
            if sz < 8 or sz % 4:
                raise ValueError(f"资源映射块尺寸异常: {sz}")
            pos += sz - 8
            continue
        if not (CHUNK_LO <= t <= CHUNK_HI):
            raise ValueError(f"解析错位: 块类型 0x{t:x} @ {pos - 4}")
        if t == 0x00100102 and prev == -1:   # 根元素 → 先吐 START_DOCUMENT
            prev, events = 0, events + 1
            continue
        pos += 12                              # size + lineNumber + comment
        if t in (0x00100100, 0x00100101):      # 命名空间
            pos += 8
        elif t == 0x00100102:                  # 开始元素
            pos += 12                          # ns + name + attrStart|attrSize
            ac = struct.unpack_from('<H', d, pos)[0]   # attrCount
            pos += 8 + ac * 20                 # attrCount|id + class|style + 属性表
        elif t == 0x00100103:                  # 结束元素
            pos += 8
        else:                                  # CDATA
            pos += 12
        prev = {0x00100100: prev, 0x00100101: prev,
                0x00100102: 2, 0x00100103: 3, 0x00100104: 4}[t]
        events += 1
    if pos != len(d):
        raise ValueError(f"文件未完整消费: {pos}/{len(d)}")
    return events


def find_jar():
    here = os.path.dirname(os.path.abspath(__file__))
    for base in (here, os.getcwd()):
        p = os.path.join(base, 'AXMLPrinter2.jar')
        if os.path.isfile(p):
            return p
    sys.exit("[x] 未找到 AXMLPrinter2.jar（请放在脚本同目录或当前目录）")


def run_axmlprinter(jar, xml_path):
    if not shutil.which('java'):
        sys.exit("[x] 未找到 java，请先安装 JDK 并加入 PATH")
    cmd = ['java', '-Dfile.encoding=UTF-8', '-jar', jar, xml_path]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = p.stdout.decode('utf-8', errors='replace')
    err = p.stderr.decode('utf-8', errors='replace')
    if p.returncode != 0 or 'Exception' in err or 'IOException' in err:
        sys.exit(f"[x] AXMLPrinter2 解码失败:\n{err.strip()}")
    return out


def summarize(xml_text):
    pkg = re.search(r'package="([^"]+)"', xml_text)
    print(f"[+] 包名: {pkg.group(1) if pkg else '?'}")
    for tag in ('activity', 'service', 'receiver', 'provider'):
        n = len(re.findall(r'<' + tag + r'[\s>]', xml_text))
        if n:
            print(f"    {tag}: {n}")
    app = re.search(r'<application[^>]*android:name="([^"]+)"', xml_text, re.S)
    if app:
        print(f"    Application: {app.group(1)}")


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)
    target = args[0]
    extra_apks = args[1:]
    if not os.path.isfile(target):
        sys.exit(f"[x] 文件不存在: {target}")

    data = read_file(target)
    base = os.path.splitext(target)[0]
    clean, clean_from = data, None

    # ---- 第 1 步：拿到干净二进制 ----
    if data[:4] == b'PK\x03\x04':
        print(f"[i] 输入是 APK/ZIP，二进制提取 AndroidManifest.xml ...")
        clean, clean_from = extract_manifest(target), target
    elif data[:2] == b'\x03\x00':
        corr = data.count(b'\xef\xbf\xbd')
        if corr > 16:
            print(f"[!] 检测到 {corr} 处 UTF-8 替换字符 (EF BF BD)：文件曾被文本模式损坏")
            candidates = extra_apks + sorted(glob.glob('*.apk'))
            apk, orig = find_source_apk(data, candidates)
            if apk:
                clean, clean_from = orig, apk
                print(f"[+] 已定位来源 APK: {os.path.basename(apk)}，重新提取干净二进制")
            else:
                print("[!] 未找到匹配的来源 APK，强行尝试（结果可能有误；"
                      "可把候选 APK 作为额外参数传入）")
    elif data.lstrip()[:5] == b'<?xml':
        print("[i] 文件已是可读文本 XML，无需修复")
        return
    else:
        sys.exit("[x] 无法识别的文件格式（既不是 AXML 也不是 APK）")

    if clean_from:
        write_file(f"{base}_clean.xml", clean)

    # ---- 第 2 步：补丁 + 模拟验证 ----
    patched, was_patched, notes = patch_axml(clean)
    for n in notes:
        print(f"[i] {n}")
    if was_patched:
        write_file(f"{base}_patched.xml", patched)
    events = verify_walk(patched)
    print(f"[+] 结构模拟走查通过（{events} 个事件，字节全部对齐）")

    # ---- 第 3 步：AXMLPrinter2 解码 ----
    jar = find_jar()
    src = f"{base}_patched.xml" if was_patched else (
        f"{base}_clean.xml" if clean_from else target)
    xml_text = run_axmlprinter(jar, src)
    if '<manifest' not in xml_text or '</manifest>' not in xml_text:
        sys.exit("[x] 解码输出不完整，请人工检查")
    write_file(f"{base}_recovered.xml", xml_text.encode('utf-8'))

    # ---- 第 4 步：统计摘要 ----
    summarize(xml_text)
    print(f"[+] 完成! 可读 XML: {base}_recovered.xml")


if __name__ == '__main__':
    main()
